mod buffer;

use crate::buffer::color::Color;
use crate::buffer::math::vec3::Vec3;
use crate::buffer::Savable;

fn main() {
    let mut buf: buffer::Buffer = buffer::Buffer::new(512, 512);
    buf.clear_color(Color {
        r: 255,
        g: 200,
        b: 100,
    });
    buf.clear_depth(1.);
    buf.draw_triangle(
        Vec3 {
            x: 200.,
            y: -20.,
            z: 0.,
        },
        Vec3 {
            x: 100.,
            y: 100.,
            z: 1.,
        },
        Vec3 {
            x: 220.,
            y: 225.,
            z: 0.,
        },
        Color {
            r: 123,
            g: 200,
            b: 0,
        },
        Color {
            r: 255,
            g: 110,
            b: 200,
        },
        Color { r: 0, g: 0, b: 255 },
    );
    buf.draw_triangle(
        Vec3 {
            x: 300.,
            y: -20.,
            z: 0.,
        },
        Vec3 {
            x: 100.,
            y: 200.,
            z: 0.,
        },
        Vec3 {
            x: 300.,
            y: 200.,
            z: 1.,
        },
        Color { r: 0, g: 255, b: 0 },
        Color {
            r: 255,
            g: 100,
            b: 0,
        },
        Color { r: 0, g: 0, b: 255 },
    );

    buf.draw_triangle(
        Vec3 {
            x: 350.,
            y: 300.,
            z: 0.,
        },
        Vec3 {
            x: 150.,
            y: 450.,
            z: 0.,
        },
        Vec3 {
            x: 350.,
            y: 450.,
            z: 0.,
        },
        Color {
            r: 255,
            g: 255,
            b: 0,
        },
        Color { r: 0, g: 255, b: 0 },
        Color { r: 0, g: 0, b: 255 },
    );

    buf.draw_triangle(
        Vec3 {
            x: 150.,
            y: 300.,
            z: 0.,
        },
        Vec3 {
            x: 150.,
            y: 450.,
            z: 0.,
        },
        Vec3 {
            x: 350.,
            y: 300.,
            z: 0.,
        },
        Color { r: 255, g: 0, b: 0 },
        Color {
            r: 255,
            g: 255,
            b: 0,
        },
        Color {
            r: 255,
            g: 255,
            b: 0,
        },
    );
    buf.save_to_png("image.png");
}
