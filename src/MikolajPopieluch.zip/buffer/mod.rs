extern crate image;

pub mod color;
use color::Color;

pub mod math;
use math::vec3::Vec3;

pub mod pixel;
use pixel::Pixel;

pub trait Savable {
    fn save_to_png(&self, path: &str);
}
pub struct Buffer {
    pub width: u32,
    pub height: u32,
    pub data: Vec<Pixel>,
    pub depth: Vec<f32>,
}

impl Buffer {
    pub fn new(_width: u32, _height: u32) -> Buffer {
        Buffer {
            width: _width,
            height: _height,
            data: Vec::new(),
            depth: Vec::new(),
        }
    }

    pub fn clear_color(&mut self, c: Color) {
        self.data.clear();

        for _ in 0..self.width {
            for _ in 0..self.height {
                self.data.push(Pixel::new(c.r, c.g, c.b));
            }
        }
    }

    pub fn clear_depth(&mut self, value: f32) {
        for _ in 0..self.width {
            for _ in 0..self.height {
                self.depth.push(value);
            }
        }
    }

    pub fn draw_triangle(
        &mut self,
        va: Vec3,
        vb: Vec3,
        vc: Vec3,
        mut c1: Color,
        mut c2: Color,
        mut c3: Color,
    ) {
        let maxx = f32::max(va.x, vb.x).max(vc.x).min(self.width as f32 - 1.);
        let maxy = f32::max(va.y, vb.y).max(vc.y).min(self.height as f32 - 1.);
        let minx = f32::min(va.x, vb.x).min(vc.x).max(0.) as i32;
        let miny = f32::min(va.y, vb.y).min(vc.y).max(0.) as i32;

        let ax = (va.x as i64 + 1) * self.width as i64 >> 2;
        let ay = (va.y as i64 + 1) * self.height as i64 >> 2;

        let bx = (vb.x as i64 + 1) * self.width as i64 >> 2;
        let by = (vb.y as i64 + 1) * self.height as i64 >> 2;

        let cx = (vc.x as i64 + 1) * self.width as i64 >> 2;
        let cy = (vc.y as i64 + 1) * self.height as i64 >> 2;

        let dxab = ax - bx;
        let dxbc = bx - cx;
        let dxca = cx - ax;
        let dyab = ay - by;
        let dybc = by - cy;
        let dyca = cy - ay;

        let c1_n = c1.normalize();
        let c2_n = c2.normalize();
        let c3_n = c3.normalize();

        for h in minx..maxx as i32 {
            for w in miny..maxy as i32 {
                let x: i64 = (h as i64 + 1) * self.height as i64 >> 2;
                let y: i64 = (w as i64 + 1) * self.width as i64 >> 2;

                let l1: f32 = (((dybc) * (x - cx) + (cx - bx) * (y - cy)) as f32
                    / ((dybc) * (ax - cx) + (cx - bx) * (ay - cy)) as f32)
                    as f32;
                let l2: f32 = (((cx - ay) * (x - cx) + (ax - cx) * (y - cy)) as f32
                    / ((dyca) * (dxbc) + (ax - cx) * (dybc)) as f32)
                    as f32;
                let l3: f32 = 1.0 - l1 - l2;

                let rc: f32 = l1 * c1_n.0 + l2 * c2_n.0 + l3 * c3_n.0;
                let gc: f32 = l1 * c1_n.1 + l2 * c2_n.1 + l3 * c3_n.1;
                let bc: f32 = l1 * c1_n.2 + l2 * c2_n.2 + l3 * c3_n.2;

                let base = h + self.width as i32 * w;

                let topleft1 = dyab < 0 || (dyab == 0 && dxab > 0);
                let topleft2 = dybc < 0 || (dybc == 0 && dxbc > 0);
                let topleft3 = dyca < 0 || (dyca == 0 && dxca > 0);

                let depth = l1 * va.z as f32 + l2 * vb.z as f32 + l3 * vc.z as f32;

                let inside = ((dxab) * (y - ay)) - ((dyab) * (x - ax)) > 0 && !topleft1
                    || ((dxab) * (y - ay)) - ((dyab) * (x - ax)) >= 0
                        && topleft1
                        && ((dxbc) * (y - by)) - ((dybc) * (x - bx)) > 0
                        && !topleft2
                    || ((dxbc) * (y - by)) - ((dybc) * (x - bx)) >= 0
                        && topleft2
                        && ((dxca) * (y - cy)) - ((dyca) * (x - cx)) > 0
                        && !topleft3
                    || ((dxca) * (y - cy)) - ((dyca) * (x - cx)) >= 0 && topleft3;

                let on_top = depth < self.depth[base as usize];

                if inside && on_top {
                    self.data[base as usize] =
                        Pixel::new((rc * 255.0) as u8, (gc * 255.0) as u8, (bc * 255.0) as u8);
                    self.depth[base as usize] = depth;
                }
            }
        }
    }

    fn data_as_u8_vec(&self) -> Vec<u8> {
        let mut u8_vec = Vec::<u8>::new();
        for el in &self.data {
            u8_vec.push(el.color.r);
            u8_vec.push(el.color.g);
            u8_vec.push(el.color.b);
        }
        u8_vec
    }
}

impl Savable for Buffer {
    fn save_to_png(&self, path: &str) {
        image::save_buffer(
            path,
            self.data_as_u8_vec().as_slice(),
            self.height,
            self.width,
            image::ColorType::Rgb8,
        )
        .unwrap();
    }
}
