mod buffer;

use crate::buffer::color::Color;
use crate::buffer::math::mat4::Mat4;
use crate::buffer::math::mat4::ProjectionMatrix;
use crate::buffer::math::mat4::WorldMatrix;
use crate::buffer::Savable;

fn main() {
    let proj: Mat4 = Mat4::create_perspective(100., 3. / 3., 0.1, 1000.);
    let world: Mat4 = Mat4::set_lookat([0., 0., 15.], [0., 0., 0.], [0., 1., 0.]);
    let mut buf: buffer::Buffer = buffer::Buffer::new(512, 512, proj, world);
    buf.clear_color(Color { r: 0, g: 0, b: 0 });
    buf.clear_depth(1000.);

    buf.rotate(45., [0., 1., 0.]);
    buf.translate([-3., 0., 0.]);
    //buf.scale([0.5, 0.5, 0.5]);

    buf.draw_triangle(
        [-1.0, 1.0, 1.0],
        [-1.0, -1.0, 1.0],
        [-1.0, -1.0, -1.0],
        Color { r: 255, g: 0, b: 0 },
        Color { r: 255, g: 0, b: 0 },
        Color { r: 255, g: 0, b: 0 },
    );

    buf.draw_triangle(
        [-1.0, 1.0, -1.0],
        [-1.0, -1.0, -1.0],
        [1.0, 1.0, -1.0],
        Color { r: 100, g: 0, b: 0 },
        Color { r: 100, g: 0, b: 0 },
        Color { r: 100, g: 0, b: 0 },
    );

    buf.draw_triangle(
        [1.0, -1.0, -1.0],
        [-1.0, -1.0, -1.0],
        [1.0, -1.0, 1.0],
        Color { r: 0, g: 123, b: 0 },
        Color { r: 0, g: 123, b: 0 },
        Color { r: 0, g: 123, b: 0 },
    );

    buf.draw_triangle(
        [-1.0, -1.0, -1.0],
        [1.0, -1.0, -1.0],
        [1.0, 1.0, -1.0],
        Color { r: 0, g: 0, b: 255 },
        Color { r: 0, g: 0, b: 255 },
        Color { r: 0, g: 0, b: 255 },
    );

    buf.draw_triangle(
        [-1.0, 1.0, -1.0],
        [-1.0, 1.0, 1.0],
        [-1.0, -1.0, -1.0],
        Color {
            r: 111,
            g: 123,
            b: 0,
        },
        Color {
            r: 111,
            g: 123,
            b: 0,
        },
        Color {
            r: 111,
            g: 123,
            b: 0,
        },
    );

    buf.draw_triangle(
        [-1.0, -1.0, -1.0],
        [-1.0, -1.0, 1.0],
        [1.0, -1.0, 1.0],
        Color { r: 50, g: 0, b: 50 },
        Color { r: 50, g: 0, b: 50 },
        Color { r: 50, g: 0, b: 50 },
    );

    buf.draw_triangle(
        [1.0, -1.0, 1.0],
        [-1.0, -1.0, 1.0],
        [-1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 50,
            b: 50,
        },
        Color {
            r: 50,
            g: 50,
            b: 50,
        },
        Color {
            r: 50,
            g: 50,
            b: 50,
        },
    );

    buf.draw_triangle(
        [1.0, 1.0, -1.0],
        [1.0, -1.0, -1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 150,
            b: 50,
        },
        Color {
            r: 50,
            g: 150,
            b: 50,
        },
        Color {
            r: 50,
            g: 150,
            b: 50,
        },
    );

    buf.draw_triangle(
        [1.0, -1.0, 1.0],
        [1.0, 1.0, 1.0],
        [1.0, -1.0, -1.0],
        Color {
            r: 50,
            g: 150,
            b: 150,
        },
        Color {
            r: 50,
            g: 150,
            b: 150,
        },
        Color {
            r: 50,
            g: 150,
            b: 150,
        },
    );

    buf.draw_triangle(
        [-1.0, 1.0, -1.0],
        [1.0, 1.0, -1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 150,
            b: 250,
        },
        Color {
            r: 50,
            g: 150,
            b: 250,
        },
        Color {
            r: 50,
            g: 150,
            b: 250,
        },
    );

    buf.draw_triangle(
        [-1.0, 1.0, 1.0],
        [-1.0, 1.0, -1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 250,
            b: 150,
        },
        Color {
            r: 50,
            g: 250,
            b: 150,
        },
        Color {
            r: 50,
            g: 250,
            b: 150,
        },
    );

    buf.draw_triangle(
        [1.0, -1.0, 1.0],
        [-1.0, 1.0, 1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 150,
            g: 150,
            b: 150,
        },
        Color {
            r: 150,
            g: 150,
            b: 150,
        },
        Color {
            r: 150,
            g: 150,
            b: 150,
        },
    );

    buf.clear_object_matrices();
    
    buf.rotate(45., [1., 0., 0.]);
    buf.scale([0.5, 0.5, 0.5]);
    //buf.translate([1.2, 0., 0.]);


    buf.draw_triangle(
        [-1.0, 1.0, 1.0],
        [-1.0, -1.0, 1.0],
        [-1.0, -1.0, -1.0],
        Color { r: 255, g: 0, b: 0 },
        Color { r: 255, g: 0, b: 0 },
        Color { r: 255, g: 0, b: 0 },
    );

    buf.draw_triangle(
        [-1.0, 1.0, -1.0],
        [-1.0, -1.0, -1.0],
        [1.0, 1.0, -1.0],
        Color { r: 100, g: 0, b: 0 },
        Color { r: 100, g: 0, b: 0 },
        Color { r: 100, g: 0, b: 0 },
    );

    buf.draw_triangle(
        [1.0, -1.0, -1.0],
        [-1.0, -1.0, -1.0],
        [1.0, -1.0, 1.0],
        Color { r: 0, g: 123, b: 0 },
        Color { r: 0, g: 123, b: 0 },
        Color { r: 0, g: 123, b: 0 },
    );

    buf.draw_triangle(
        [-1.0, -1.0, -1.0],
        [1.0, -1.0, -1.0],
        [1.0, 1.0, -1.0],
        Color { r: 0, g: 0, b: 255 },
        Color { r: 0, g: 0, b: 255 },
        Color { r: 0, g: 0, b: 255 },
    );

    buf.draw_triangle(
        [-1.0, 1.0, -1.0],
        [-1.0, 1.0, 1.0],
        [-1.0, -1.0, -1.0],
        Color {
            r: 111,
            g: 123,
            b: 0,
        },
        Color {
            r: 111,
            g: 123,
            b: 0,
        },
        Color {
            r: 111,
            g: 123,
            b: 0,
        },
    );

    buf.draw_triangle(
        [-1.0, -1.0, -1.0],
        [-1.0, -1.0, 1.0],
        [1.0, -1.0, 1.0],
        Color { r: 50, g: 0, b: 50 },
        Color { r: 50, g: 0, b: 50 },
        Color { r: 50, g: 0, b: 50 },
    );

    buf.draw_triangle(
        [1.0, -1.0, 1.0],
        [-1.0, -1.0, 1.0],
        [-1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 50,
            b: 50,
        },
        Color {
            r: 50,
            g: 50,
            b: 50,
        },
        Color {
            r: 50,
            g: 50,
            b: 50,
        },
    );

    buf.draw_triangle(
        [1.0, 1.0, -1.0],
        [1.0, -1.0, -1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 150,
            b: 50,
        },
        Color {
            r: 50,
            g: 150,
            b: 50,
        },
        Color {
            r: 50,
            g: 150,
            b: 50,
        },
    );

    buf.draw_triangle(
        [1.0, -1.0, 1.0],
        [1.0, 1.0, 1.0],
        [1.0, -1.0, -1.0],
        Color {
            r: 50,
            g: 150,
            b: 150,
        },
        Color {
            r: 50,
            g: 150,
            b: 150,
        },
        Color {
            r: 50,
            g: 150,
            b: 150,
        },
    );

    buf.draw_triangle(
        [-1.0, 1.0, -1.0],
        [1.0, 1.0, -1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 150,
            b: 250,
        },
        Color {
            r: 50,
            g: 150,
            b: 250,
        },
        Color {
            r: 50,
            g: 150,
            b: 250,
        },
    );

    buf.draw_triangle(
        [-1.0, 1.0, 1.0],
        [-1.0, 1.0, -1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 50,
            g: 250,
            b: 150,
        },
        Color {
            r: 50,
            g: 250,
            b: 150,
        },
        Color {
            r: 50,
            g: 250,
            b: 150,
        },
    );

    buf.draw_triangle(
        [1.0, -1.0, 1.0],
        [-1.0, 1.0, 1.0],
        [1.0, 1.0, 1.0],
        Color {
            r: 150,
            g: 150,
            b: 150,
        },
        Color {
            r: 150,
            g: 150,
            b: 150,
        },
        Color {
            r: 150,
            g: 150,
            b: 150,
        },
    );

    
    // buf.draw_triangle(
    //     [-0.5, -0.8, 0.],
    //     [-0.5, 0.5, 0.],
    //     [0.5, 0.5, 0.],
    //     Color { r: 0, g: 0, b: 255 },
    //     Color { r: 255, g: 0, b: 0 },
    //     Color { r: 0, g: 255, b: 0 },
    // );

    buf.save_to_png("image.png");
}
