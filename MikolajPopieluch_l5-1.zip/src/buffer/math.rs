pub mod slice_ops;

pub mod mat4;
pub mod matrix;
#[macro_use]
pub mod vector;
pub mod vec3;
pub mod vec4;
